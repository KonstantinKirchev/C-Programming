int arr_min(char line[]);
int arr_max(char line[]);
void arr_clear(char line[]);
double arr_average(char arr[]);
double arr_sum(char arr[]);
int arr_contains(char arr[], char element[]);
void arr_merge(char arr1[], char arr2[], char output[]);


