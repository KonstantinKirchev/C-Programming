#include <stdio.h>
#include <stdlib.h>


int main() {
    char firstName[] = "Konstantin";
    char lastName[] = "Kirchev";
    printf("%s\n%s", firstName, lastName);
    return (EXIT_SUCCESS);
}

