#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("My name is Konstantin.");
    return (EXIT_SUCCESS);
}

