
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
    float number;
    scanf("%f", &number);
    float result = sqrt(number);
    printf("%f", result);
    return (EXIT_SUCCESS);
}

