#include <stdio.h>
#include <stdlib.h>

int main() {
    char name[10];
    scanf("%s", name);
    printf("%s",name);
    return (EXIT_SUCCESS);
}

