#include <stdio.h>
#include <stdlib.h>

int main() {
    int one = 1;
    int hundredAndOne = 101;
    int thousandAndOne = 1001;
    printf("%d\n%d\n%d", one, hundredAndOne, thousandAndOne);
    return (EXIT_SUCCESS);
}

