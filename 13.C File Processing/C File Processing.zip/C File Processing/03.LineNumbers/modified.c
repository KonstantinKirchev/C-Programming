0  #include <stdio.h>
1  
2  int main() 
3  {
4      printf("Spicy");
5  
6      return 0;
7  }