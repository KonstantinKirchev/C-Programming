#include <stdio.h>

int main() 
{
    printf("Spicy");

    return 0;
}