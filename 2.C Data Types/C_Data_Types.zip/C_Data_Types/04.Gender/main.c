#include <stdio.h>
#include <stdlib.h>

int main() {
    int isFemale = 0;
    if (isFemale) {
        printf("true");
    }
    else{
        printf("false");
    }
    return (EXIT_SUCCESS);
}

