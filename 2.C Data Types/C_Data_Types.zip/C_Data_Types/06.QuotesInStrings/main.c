#include <stdio.h>
#include <stdlib.h>

int main() {
    char string[] = "The \"use\" of quotations causes difficulties. \\n, \\t and \\ are also special characters.";
    
    printf("%s", string);
    
    return (EXIT_SUCCESS);
}

