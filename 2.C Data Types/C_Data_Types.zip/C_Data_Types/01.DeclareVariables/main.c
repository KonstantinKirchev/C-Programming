#include <stdio.h>
#include <stdlib.h>

int main() {
    
    unsigned short shortNum = 52130;
    long longNumOne = 8942492113;
    char charNumOne = -115;
    int intNumOne = 4825932;
    char charNumTwo = 97;
    int intNumTwo = -10000;
    long long longNumTwo = -35982859328592389;

    return (EXIT_SUCCESS);
}

