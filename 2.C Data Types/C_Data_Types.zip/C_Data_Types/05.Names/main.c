#include <stdio.h>
#include <stdlib.h>

int main() {
    char firstName[11] = "Konstantin";
    char lastName[8] = "Kirchev";
    
    printf("%s %s", firstName, lastName);
    
    return (EXIT_SUCCESS);
}

