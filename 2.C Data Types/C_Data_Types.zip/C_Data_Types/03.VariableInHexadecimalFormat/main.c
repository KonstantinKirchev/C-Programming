#include <stdio.h>
#include <stdlib.h>

int main() {
    int hexNum = 0xFE;
    printf("%d", hexNum);
    return (EXIT_SUCCESS);
}

