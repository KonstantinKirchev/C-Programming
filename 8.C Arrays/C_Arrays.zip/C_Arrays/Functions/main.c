/* 
 * File:   main.c
 * Author: konstantin
 *
 * Created on October 26, 2015, 4:24 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

